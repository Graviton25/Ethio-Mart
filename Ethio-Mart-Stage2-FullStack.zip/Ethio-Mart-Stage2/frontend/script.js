const products = [
  {id:1,name:"Ethiopian Single-Origin Coffee",category:"Food & Drinks",price:450,rating:4.9,badge:"Popular",image:"https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=900&q=80",description:"A rich roasted coffee selection inspired by Ethiopia's coffee culture."},
  {id:2,name:"Pure Ethiopian Honey",category:"Food & Drinks",price:620,rating:4.8,badge:"Local",image:"https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=900&q=80",description:"Golden honey for tea, breakfast and everyday use."},
  {id:3,name:"Handmade Mesob Basket",category:"Home & Living",price:1250,rating:4.7,badge:"Craft",image:"https://images.unsplash.com/photo-1590736969955-71cc94901144?auto=format&fit=crop&w=900&q=80",description:"A decorative handmade basket inspired by Ethiopian weaving traditions."},
  {id:4,name:"Wireless Headphones",category:"Electronics",price:2850,rating:4.6,badge:"Deal",image:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80",description:"Comfortable wireless headphones for music, study and calls."},
  {id:5,name:"Classic Canvas Backpack",category:"Fashion",price:1950,rating:4.5,badge:"New",image:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80",description:"A practical everyday backpack with a clean minimalist design."},
  {id:6,name:"Ceramic Coffee Set",category:"Home & Living",price:1650,rating:4.7,badge:"Home",image:"https://images.unsplash.com/photo-1514228742587-6b1558fcf93a?auto=format&fit=crop&w=900&q=80",description:"Simple ceramic cups for coffee time with friends and family."},
  {id:7,name:"Everyday Running Shoes",category:"Fashion",price:3400,rating:4.6,badge:"Popular",image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80",description:"Lightweight shoes for walking, running and everyday movement."},
  {id:8,name:"Study Desk Lamp",category:"Electronics",price:980,rating:4.4,badge:"Value",image:"https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=80",description:"A compact desk lamp for late-night study and work."}
];

const categories = [
  ["☕","Food & Drinks"],["⌂","Home & Living"],["◈","Electronics"],["◉","Fashion"],["✦","Beauty"],["▦","All"]
];

let cart = JSON.parse(localStorage.getItem("ethioCart") || "[]");
let favorites = JSON.parse(localStorage.getItem("ethioFavorites") || "[]");
let activeCategory = "All";

const productGrid = document.getElementById("productGrid");
const categoryGrid = document.getElementById("categoryGrid");
const searchInput = document.getElementById("searchInput");
const resultsLabel = document.getElementById("resultsLabel");
const emptyState = document.getElementById("emptyState");
const cartDrawer = document.getElementById("cartDrawer");
const cartOverlay = document.getElementById("cartOverlay");
const cartItems = document.getElementById("cartItems");
const cartTotal = document.getElementById("cartTotal");
const cartCount = document.getElementById("cartCount");
const favoriteCount = document.getElementById("favoriteCount");
const toast = document.getElementById("toast");

const money = n => `${n.toLocaleString()} ETB`;

function save() {
  localStorage.setItem("ethioCart", JSON.stringify(cart));
  localStorage.setItem("ethioFavorites", JSON.stringify(favorites));
}

function renderCategories() {
  categoryGrid.innerHTML = categories.map(([icon,name]) => `
    <button class="category-card ${activeCategory === name ? "active" : ""}" data-category="${name}">
      <div class="category-icon">${icon}</div><strong>${name}</strong>
    </button>
  `).join("");
}

function filteredProducts() {
  const q = searchInput.value.trim().toLowerCase();
  return products.filter(p =>
    (activeCategory === "All" || p.category === activeCategory) &&
    (!q || `${p.name} ${p.category}`.toLowerCase().includes(q))
  );
}

function renderProducts() {
  const list = filteredProducts();
  resultsLabel.textContent = `${list.length} product${list.length === 1 ? "" : "s"}`;
  emptyState.classList.toggle("hidden", list.length !== 0);
  productGrid.innerHTML = list.map(p => `
    <article class="product-card">
      <div class="product-image">
        <img src="${p.image}" alt="${p.name}" loading="lazy">
        <span class="badge">${p.badge}</span>
        <button class="product-fav ${favorites.includes(p.id) ? "active" : ""}" data-fav="${p.id}" aria-label="Favorite">${favorites.includes(p.id) ? "♥" : "♡"}</button>
      </div>
      <div class="product-info">
        <span class="product-category">${p.category}</span>
        <h3>${p.name}</h3>
        <div class="rating">★★★★★ <span>${p.rating}</span></div>
        <div class="price-row"><span class="price">${money(p.price)}</span><button class="add-btn" data-add="${p.id}" aria-label="Add to cart">+</button></div>
      </div>
    </article>
  `).join("");
}

function renderCart() {
  const count = cart.reduce((sum,item) => sum + item.qty, 0);
  const total = cart.reduce((sum,item) => sum + item.qty * item.price, 0);
  cartCount.textContent = count;
  favoriteCount.textContent = favorites.length;
  cartTotal.textContent = money(total);

  if (!cart.length) {
    cartItems.innerHTML = `<div class="empty-state"><div>🛒</div><h3>Your cart is empty</h3><p>Add something you like and it will appear here.</p></div>`;
    return;
  }

  cartItems.innerHTML = cart.map(item => `
    <div class="cart-item">
      <img class="cart-item-img" src="${item.image}" alt="${item.name}">
      <div>
        <h4>${item.name}</h4>
        <p>${money(item.price)}</p>
        <div class="qty">
          <button data-qty="-1" data-id="${item.id}">−</button><span>${item.qty}</span><button data-qty="1" data-id="${item.id}">+</button>
        </div>
      </div>
      <button class="remove" data-remove="${item.id}">Remove</button>
    </div>
  `).join("");
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toast.classList.remove("show"), 1800);
}

function addToCart(id) {
  const p = products.find(x => x.id === id);
  const existing = cart.find(x => x.id === id);
  if (existing) existing.qty++;
  else cart.push({...p, qty:1});
  save(); renderCart(); showToast(`${p.name} added to cart`);
}

function toggleFavorite(id) {
  favorites = favorites.includes(id) ? favorites.filter(x => x !== id) : [...favorites,id];
  save(); renderProducts(); renderCart();
  showToast(favorites.includes(id) ? "Added to favorites ♥" : "Removed from favorites");
}

function openCart() { cartDrawer.classList.add("open"); cartOverlay.classList.add("open"); }
function closeCart() { cartDrawer.classList.remove("open"); cartOverlay.classList.remove("open"); }

function openProduct(id) {
  const p = products.find(x => x.id === id);
  document.getElementById("productModal").innerHTML = `
    <div class="modal-content">
      <img src="${p.image}" alt="${p.name}">
      <div class="modal-copy">
        <span class="product-category">${p.category}</span>
        <h2>${p.name}</h2>
        <div class="rating">★★★★★ ${p.rating}</div>
        <p>${p.description}</p>
        <div class="modal-price">${money(p.price)}</div>
        <button class="btn btn-primary full" data-modal-add="${p.id}">Add to cart</button>
      </div>
    </div>`;
  document.getElementById("modalBackdrop").classList.remove("hidden");
}

function assistantReply(text) {
  const q = text.toLowerCase();
  if (q.includes("coffee")) return "Try our Ethiopian Single-Origin Coffee for 450 ETB. ☕";
  if (q.includes("cheap") || q.includes("affordable")) return "The Study Desk Lamp is 980 ETB, while the coffee is 450 ETB. You can also sort/filter products later when the backend is added.";
  if (q.includes("checkout")) return "Add products to the cart, review quantities, then press “Continue to checkout”. The current checkout is a frontend demo.";
  return "I’m currently a demo assistant. I can help with products, prices and basic shopping questions. A real AI service can be connected securely through the backend.";
}

document.addEventListener("click", e => {
  const category = e.target.closest("[data-category]");
  if (category) { activeCategory = category.dataset.category; renderCategories(); renderProducts(); }

  const add = e.target.closest("[data-add]");
  if (add) addToCart(Number(add.dataset.add));

  const fav = e.target.closest("[data-fav]");
  if (fav) toggleFavorite(Number(fav.dataset.fav));

  const card = e.target.closest(".product-card");
  if (card && !e.target.closest("button")) {
    const img = card.querySelector("img").alt;
    const p = products.find(x => x.name === img);
    if (p) openProduct(p.id);
  }

  const qty = e.target.closest("[data-qty]");
  if (qty) {
    const item = cart.find(x => x.id === Number(qty.dataset.id));
    if (item) item.qty += Number(qty.dataset.qty);
    cart = cart.filter(x => x.qty > 0);
    save(); renderCart();
  }

  const remove = e.target.closest("[data-remove]");
  if (remove) { cart = cart.filter(x => x.id !== Number(remove.dataset.remove)); save(); renderCart(); }

  const modalAdd = e.target.closest("[data-modal-add]");
  if (modalAdd) { addToCart(Number(modalAdd.dataset.modalAdd)); document.getElementById("modalBackdrop").classList.add("hidden"); }

  const prompt = e.target.closest("[data-prompt]");
  if (prompt) sendMessage(prompt.dataset.prompt);
});

searchInput.addEventListener("input", renderProducts);
document.getElementById("cartBtn").addEventListener("click", openCart);
document.getElementById("closeCart").addEventListener("click", closeCart);
cartOverlay.addEventListener("click", closeCart);
document.getElementById("closeAssistant").addEventListener("click", () => document.getElementById("assistantPanel").classList.remove("open"));
document.getElementById("assistantBtn").addEventListener("click", () => document.getElementById("assistantPanel").classList.toggle("open"));
document.getElementById("mobileMenuBtn").addEventListener("click", () => {
  const nav = document.getElementById("mainNav");
  nav.style.display = nav.style.display === "flex" ? "" : "flex";
  nav.style.position = "absolute"; nav.style.top = "65px"; nav.style.left = "0"; nav.style.right = "0";
  nav.style.background = "var(--surface)"; nav.style.padding = "20px"; nav.style.flexDirection = "column";
});

document.getElementById("themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  localStorage.setItem("ethioTheme", document.body.classList.contains("dark") ? "dark" : "light");
});
if (localStorage.getItem("ethioTheme") === "dark") document.body.classList.add("dark");

document.getElementById("modalBackdrop").addEventListener("click", e => {
  if (e.target.id === "modalBackdrop") e.target.classList.add("hidden");
});

document.getElementById("filterBtn").addEventListener("click", () => {
  document.getElementById("categories").scrollIntoView({behavior:"smooth"});
  showToast("Choose a category to filter products");
});

document.getElementById("favoritesBtn").addEventListener("click", () => {
  const favs = products.filter(p => favorites.includes(p.id));
  if (!favs.length) return showToast("No favorites yet");
  activeCategory = "All";
  searchInput.value = "";
  productGrid.innerHTML = favs.map(p => `
    <article class="product-card">
      <div class="product-image"><img src="${p.image}" alt="${p.name}"><span class="badge">Favorite</span><button class="product-fav active" data-fav="${p.id}">♥</button></div>
      <div class="product-info"><span class="product-category">${p.category}</span><h3>${p.name}</h3><div class="rating">★★★★★ ${p.rating}</div><div class="price-row"><span class="price">${money(p.price)}</span><button class="add-btn" data-add="${p.id}">+</button></div></div>
    </article>`).join("");
  resultsLabel.textContent = `${favs.length} favorite${favs.length === 1 ? "" : "s"}`;
  document.getElementById("products").scrollIntoView({behavior:"smooth"});
});

document.getElementById("checkoutBtn").addEventListener("click", () => {
  if (!cart.length) return showToast("Your cart is empty");
  showToast("Checkout interface ready — backend/payment comes next");
});

const chatForm = document.getElementById("chatForm");
const chatMessages = document.getElementById("chatMessages");
function sendMessage(text) {
  chatMessages.insertAdjacentHTML("beforeend", `<div class="user-message">${text}</div><div class="bot-message">${assistantReply(text)}</div>`);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}
chatForm.addEventListener("submit", e => {
  e.preventDefault();
  const input = document.getElementById("chatInput");
  const text = input.value.trim();
  if (!text) return;
  sendMessage(text); input.value = "";
});

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => { if (entry.isIntersecting) entry.target.classList.add("visible"); });
},{threshold:.12});
document.querySelectorAll(".section-animate").forEach(el => observer.observe(el));

renderCategories();
renderProducts();
renderCart();
