const Database = require("better-sqlite3");
const path = require("path");

const db = new Database(path.join(__dirname, "ethio-mart.db"));

db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    price INTEGER NOT NULL,
    rating REAL DEFAULT 0,
    badge TEXT,
    image TEXT,
    description TEXT
  );

  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    address TEXT,
    total INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS order_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    product_name TEXT NOT NULL,
    price INTEGER NOT NULL,
    quantity INTEGER NOT NULL,
    FOREIGN KEY(order_id) REFERENCES orders(id)
  );
`);

const count = db.prepare("SELECT COUNT(*) AS count FROM products").get().count;

if (count === 0) {
  const insert = db.prepare(`
    INSERT INTO products
    (name, category, price, rating, badge, image, description)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);

  const products = [
    ["Ethiopian Single-Origin Coffee", "Food & Drinks", 450, 4.9, "Popular", "https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=900&q=80", "A rich roasted coffee selection inspired by Ethiopia's coffee culture."],
    ["Pure Ethiopian Honey", "Food & Drinks", 620, 4.8, "Local", "https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&w=900&q=80", "Golden honey for tea, breakfast and everyday use."],
    ["Handmade Mesob Basket", "Home & Living", 1250, 4.7, "Craft", "https://images.unsplash.com/photo-1590736969955-71cc94901144?auto=format&fit=crop&w=900&q=80", "A decorative handmade basket inspired by Ethiopian weaving traditions."],
    ["Wireless Headphones", "Electronics", 2850, 4.6, "Deal", "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80", "Comfortable wireless headphones for music, study and calls."],
    ["Classic Canvas Backpack", "Fashion", 1950, 4.5, "New", "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80", "A practical everyday backpack with a clean minimalist design."],
    ["Ceramic Coffee Set", "Home & Living", 1650, 4.7, "Home", "https://images.unsplash.com/photo-1514228742587-6b1558fcf93a?auto=format&fit=crop&w=900&q=80", "Simple ceramic cups for coffee time with friends and family."],
    ["Everyday Running Shoes", "Fashion", 3400, 4.6, "Popular", "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80", "Lightweight shoes for walking, running and everyday movement."],
    ["Study Desk Lamp", "Electronics", 980, 4.4, "Value", "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?auto=format&fit=crop&w=900&q=80", "A compact desk lamp for late-night study and work."]
  ];

  const insertMany = db.transaction((rows) => {
    for (const row of rows) insert.run(...row);
  });

  insertMany(products);
}

module.exports = db;
