# Ethio-Mart — Stage 2 🇪🇹

Stage 2 adds a real Node.js/Express API and SQLite database to the frontend project.

## Backend structure

```text
Ethio-Mart/
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
└── backend/
    ├── server.js
    ├── db.js
    ├── schema.sql
    ├── package.json
    └── .env.example
```

## Start the backend

Requirements:
- Node.js 18+ recommended

From the `backend` directory:

```bash
npm install
npm run dev
```

The API starts at:

```text
http://localhost:3000
```

Test:

```text
GET /api/health
GET /api/products
```

## API endpoints

- `GET /api/health`
- `GET /api/products`
- `GET /api/products/:id`
- `POST /api/orders`
- `GET /api/orders/:id`
- `PATCH /api/orders/:id/status`
- `POST /api/chat`

## Example order request

```json
{
  "customer": {
    "name": "Nathnael",
    "phone": "+251900000000",
    "address": "Addis Ababa"
  },
  "items": [
    {
      "productId": 1,
      "quantity": 2
    }
  ]
}
```

## Important

The database is created automatically as `ethio-mart.db` when the server starts.

The AI route is deliberately a local demo fallback. Real AI, payment and Google Maps credentials should be added through secure backend environment variables, not hard-coded in frontend files.
