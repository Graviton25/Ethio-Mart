require("dotenv").config();

const express = require("express");
const cors = require("cors");
const db = require("./db");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors({
  origin: process.env.FRONTEND_URL || true
}));
app.use(express.json());

app.get("/api/health", (req, res) => {
  res.json({ ok: true, service: "Ethio-Mart API" });
});

app.get("/api/products", (req, res) => {
  const { category, search } = req.query;
  let sql = "SELECT * FROM products WHERE 1=1";
  const params = {};

  if (category && category !== "All") {
    sql += " AND category = @category";
    params.category = category;
  }

  if (search) {
    sql += " AND (name LIKE @search OR category LIKE @search)";
    params.search = `%${search}%`;
  }

  sql += " ORDER BY id DESC";
  res.json(db.prepare(sql).all(params));
});

app.get("/api/products/:id", (req, res) => {
  const product = db.prepare("SELECT * FROM products WHERE id = ?").get(req.params.id);

  if (!product) {
    return res.status(404).json({ error: "Product not found" });
  }

  res.json(product);
});

app.post("/api/orders", (req, res) => {
  const { customer, items } = req.body;

  if (!customer || !customer.name || !customer.phone || !Array.isArray(items) || !items.length) {
    return res.status(400).json({
      error: "Customer name, phone and at least one item are required."
    });
  }

  const getProduct = db.prepare("SELECT id, name, price FROM products WHERE id = ?");
  let total = 0;
  const orderItems = [];

  for (const item of items) {
    const product = getProduct.get(item.productId);
    const quantity = Number(item.quantity);

    if (!product || !Number.isInteger(quantity) || quantity < 1) {
      return res.status(400).json({ error: "Invalid order item." });
    }

    total += product.price * quantity;
    orderItems.push({
      productId: product.id,
      name: product.name,
      price: product.price,
      quantity
    });
  }

  const createOrder = db.transaction(() => {
    const orderResult = db.prepare(`
      INSERT INTO orders (customer_name, phone, address, total, status)
      VALUES (?, ?, ?, ?, ?)
    `).run(
      customer.name,
      customer.phone,
      customer.address || "",
      total,
      "pending"
    );

    const orderId = orderResult.lastInsertRowid;
    const insertItem = db.prepare(`
      INSERT INTO order_items (order_id, product_id, product_name, price, quantity)
      VALUES (?, ?, ?, ?, ?)
    `);

    for (const item of orderItems) {
      insertItem.run(
        orderId,
        item.productId,
        item.name,
        item.price,
        item.quantity
      );
    }

    return orderId;
  });

  const orderId = createOrder();

  res.status(201).json({
    message: "Order created",
    orderId,
    total,
    status: "pending"
  });
});

app.get("/api/orders/:id", (req, res) => {
  const order = db.prepare("SELECT * FROM orders WHERE id = ?").get(req.params.id);

  if (!order) {
    return res.status(404).json({ error: "Order not found" });
  }

  const items = db.prepare(
    "SELECT * FROM order_items WHERE order_id = ?"
  ).all(req.params.id);

  res.json({ ...order, items });
});

app.patch("/api/orders/:id/status", (req, res) => {
  const allowed = ["pending", "confirmed", "preparing", "out_for_delivery", "delivered", "cancelled"];
  const { status } = req.body;

  if (!allowed.includes(status)) {
    return res.status(400).json({ error: "Invalid order status." });
  }

  const result = db.prepare(
    "UPDATE orders SET status = ? WHERE id = ?"
  ).run(status, req.params.id);

  if (!result.changes) {
    return res.status(404).json({ error: "Order not found" });
  }

  res.json({ message: "Order status updated", status });
});

app.post("/api/chat", (req, res) => {
  const message = String(req.body.message || "").trim();

  if (!message) {
    return res.status(400).json({ error: "Message is required." });
  }

  // Safe local fallback. Replace this route with a real AI provider later.
  const q = message.toLowerCase();
  let reply =
    "I'm the Ethio-Mart demo assistant. I can help with products, prices, orders and shopping.";

  if (q.includes("coffee")) {
    reply = "Our Ethiopian Single-Origin Coffee is currently listed at 450 ETB.";
  } else if (q.includes("cheap") || q.includes("affordable")) {
    reply = "Some lower-priced options include coffee at 450 ETB and the Study Desk Lamp at 980 ETB.";
  } else if (q.includes("order")) {
    reply = "You can place an order through the checkout interface. The backend stores orders and their status.";
  }

  res.json({ reply, mode: "demo" });
});

app.listen(PORT, () => {
  console.log(`Ethio-Mart API running at http://localhost:${PORT}`);
});
